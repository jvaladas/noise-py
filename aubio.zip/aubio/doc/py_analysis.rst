.. currentmodule:: aubio
.. default-domain:: py

Analysis
--------

.. members of generated classes are not shown

.. autoclass:: onset

.. autoclass:: pitch

.. autoclass:: tempo

.. autoclass:: notes
