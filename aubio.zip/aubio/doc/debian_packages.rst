Debian/Ubuntu packages
----------------------

For the latest Debian packages, see https://packages.debian.org/src:aubio.

For the latest Ubuntu packages, see http://packages.ubuntu.com/src:aubio.

For the latest version of the packages, see
https://anonscm.debian.org/cgit/collab-maint/aubio.git/. Use
``git-buildpackage`` to build from the git repository. For instance:

.. code-block:: console

    $ git clone git://anonscm.debian.org/collab-maint/aubio.git
    $ cd aubio
    $ git buildpackage
